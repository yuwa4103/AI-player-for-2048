 # First Step:
 pip install -r requirements.txt
 
 
 
 
 # TO RUN:   
 1.  To play the game:  
         $ python run.py
     
 2.  To let AI play for you:  
      random move: 
         $ python run.py -rand
      expectimax:  
          $ python run.py -expectimax  
