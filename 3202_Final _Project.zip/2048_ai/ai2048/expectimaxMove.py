from . import heuristics
import copy
import random

def next_move(board, n=5):
    high_score = -1
    high_move = 0
    if len(board.getEmptyCells())>4:
        pass
    else:
        n = 6


    for i in range(1,5):
        new = copy.deepcopy(board)
        mark = new.move(i)
        if board.cells == new.cells :
            continue
        score = expectimax(new, n-1, False) + mark
        if score > high_score:
            high_score = score
            high_move = i

    return high_move


def expectimax(board, n, maxs):
    if n==0:
        if not board.canMove():
            return -10000
        return heuristics.patternHeuristics(board) - heuristics.clusterHeuristics(board) + heuristics.monotonicHeuristics(board)

    if maxs:
        high_val = -1
        for i in range(1,5):
            new = copy.deepcopy(board)
            score = new.move(i)
            if board.cells == new.cells :
                continue
            val = expectimax(new, n-1, False)  + score

            if val > high_val:
                high_val = val
        return high_val

    else:
        sum_val = 0
        num = 0
        for cell in board.getEmptyCells():
            new = copy.deepcopy(board)
            x,y = cell
            new.cells[x][y] = 2

            sum_val += expectimax(new, n-1, True)

            num += 1
        if num == 0:
            return expectimax(board, n-1, True)
        return sum_val / num
            

