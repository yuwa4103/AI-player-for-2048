import numpy as np


def t_next_moves(board, n=5):
    h_score = -1
    h_move = 0
    if len(board.getEmptyCells())>4:
        pass
    else:
        n = 6
    for i in range(1,5):
        newBoard = copy.deepcopy(board)
        mark = newBoard.move(i)
        if board.cells == newBoard.cells :
            continue
        score = expectimax(newBoard, n-1, False) + mark
        if score > h_score:
            h_score = score
            h_move = i

def snext_move(board, n=3):
    step, _ = predict_move(board, n)
    return step

def spredict_moves(board, n):
    high_score = -100000000
    high_move = 0

    if n==1:
        return greedyMove.predict_next(board)

    for i in range(1,5):
        newBoard = copy.deepcopy(board)
        score = newBoard.move(i)
        if board.cells == newBoard.cells :
            continue  
        tmove, tscore = predict_move(newBoard, n-1)
        score += tscore
        if score > high_score:
            high_score = score
            high_move = i

    if high_move==0:
        high_move = random.randint(1,4)

    return high_move, high_score



def sideHeuristics(board, a1=10, a2=5, a3=1):
    score = 0
    for x in range(board.size()):
        for y in range(board.size()):
            if x==0 or x==3 or y==0 or y==3:
                if (x==0 or x==3) and (y==0 or y==3):
                    score += a1 * board.getCell(x, y)
                else:
                    score += a2 * board.getCell(x, y)
            else:
                    score += a3 * board.getCell(x, y)

    return score

def emptyHeuristics(board):

    return len(board.getEmptyCells())


def patternHeuristics(board):

    cells = np.array(board.cells)

    W = np.array([[0,0,1,3],
                  [0,1,3,5],
                  [1,3,5,15],
                  [3,5,15,30]])

                  

    return np.sum(W*cells) 

    

def clusterHeuristics(board):

    cells = np.array(board.cells)

    size = board.size()
    penalty = 0

    penalty += np.sum(np.abs(cells[:size-2,:] - cells[1:size-1,:]))
    penalty += np.sum(np.abs(cells[2:size,:] - cells[1:size-1,:]))
    penalty += np.sum(np.abs(cells[:,:size-2] - cells[:,1:size-1]))
    penalty += np.sum(np.abs(cells[:,2:size] - cells[:,1:size-1]))

    return penalty / 2
 

def monotonicHeuristics(board):

    cells = np.array(board.cells)

    size = board.size()
    cells[cells<1] = 0.1

    score1 = cells[1:size,3]/cells[:size-1,3]
    score2 = cells[3,1:size]/cells[3,:size-1]

    score = np.sum(score1[score1==2])
    score+= np.sum(score2[score2==2])

    return score * 20



    
def monotonicHeuristics2(board):

    cells = np.array(board.cells)

    size = board.size()



    score1 = cells[1:size, 2:4] - cells[:size-1,2:4]
    score1[score1>0] = 1
    score1[score1<=0] = -2

    score2 = cells[2:4, 1:size] - cells[2:4, :size-1]
    score2[score2>0] = 1
    score2[score2<=0] = -2

    score = np.sum(score1) + np.sum(score2)

    return score *10
