"""
randomMove.py
author: peterwongny
"""
import random

def next_move():


    return random.randint(1,4)