# -*- coding: UTF-8 -*-
from __future__ import print_function

import sys
from ai2048.game import Game

import argparse


def print_version_and_exit():
    from ai2048 import __version__
    print("ai2048 v%s" % __version__)
    sys.exit(0)


def print_rules_and_exit():
    print(""" win?.""")
    sys.exit(0)


def parse_cli_args():
    """parse args from the CLI and return a dict"""
    parser = argparse.ArgumentParser(description='ai 2048')
    parser.add_argument('--mode', dest='mode', type=str,
                        default=None, help='colors mode (dark or light)')
    parser.add_argument('--az', dest='azmode', action='store_true',
                        help='Use the letters a-z instead of numbers')
    parser.add_argument('--resume', dest='resume', action='store_true',
                        help='restart the game from where you left')
    parser.add_argument('-v', '--version', action='store_true')
    parser.add_argument('-r', '--rules', action='store_true')
    parser.add_argument('-rand', action='store_true', default=False)
    parser.add_argument('-expectimax', action='store_true', default=False)
    return vars(parser.parse_args())


def start_game(debug=False):
    args = parse_cli_args()

    if args['version']:
        print_version_and_exit()

    if args['rules']:
        print_rules_and_exit()

    game = Game(**args)
    if args['resume']:
        game.restore()

    if debug:
        return game

    return game.loop()
