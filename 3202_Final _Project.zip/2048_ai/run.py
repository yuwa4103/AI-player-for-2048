from ai2048.ui import start_game

start_game()